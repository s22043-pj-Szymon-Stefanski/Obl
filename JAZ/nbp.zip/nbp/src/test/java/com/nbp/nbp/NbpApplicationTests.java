package com.nbp.nbp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NbpApplicationTests {

	@Test
	void contextLoads() {
	}

}
